class Multimedia {
    constructor(src, title) {
        this.src = src;
        this.title = title;
    }

    // Métodos comunes...
}
